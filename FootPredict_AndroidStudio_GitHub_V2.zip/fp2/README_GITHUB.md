# FootPredict — version Android connectée

Cette version est configurée pour utiliser automatiquement le serveur :

`https://josephatkazad2013.pythonanywhere.com`

L'application affiche les matchs réels et le bouton **Analyser** demande l'analyse du match sélectionné au serveur.

Le serveur conserve le token Sportmonks. **Aucun token Sportmonks ne doit être placé dans l'application Android ou dans GitHub.**

## Compilation depuis GitHub

Le workflow `.github/workflows/build-apk.yml` produit un APK debug installable nommé `FootPredict.apk`.
