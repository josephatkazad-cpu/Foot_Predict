package com.footpredict.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "footpredict";
    private static final String KEY_SERVER = "server_url";
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        buildWebView();
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack(); else finish();
            }
        });
        if (getServerUrl().isEmpty()) showServerDialog(true); else loadServer();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void buildWebView() {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_AUTO);
        }
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { super.onPageStarted(view, url, favicon); }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest req, android.webkit.WebResourceError err) {
                if (req.isForMainFrame()) showErrorPage();
            }
        });
        webView.setOnLongClickListener(v -> false);
    }

    private String getServerUrl() {
        String url = prefs.getString(KEY_SERVER, BuildConfig.DEFAULT_SERVER_URL);
        return url == null ? "" : url.trim();
    }

    private void loadServer() {
        String url = getServerUrl();
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            showServerDialog(true);
            return;
        }
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        webView.loadUrl(url);
    }

    private void showErrorPage() {
        String html = "<html><body style='font-family:sans-serif;padding:30px'><h2>FootPredict</h2>" +
                "<p>Impossible de joindre le serveur.</p><p>Vérifie l'URL et la connexion Internet.</p>" +
                "<button onclick=\"location.href='https://example.com'\">Réessayer</button></body></html>";
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private void showServerDialog(boolean firstRun) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://ton-serveur.example.com");
        input.setText(getServerUrl());
        input.setSelectAllOnFocus(true);
        input.setPadding(20, 10, 20, 10);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(35, 0, 35, 0);
        TextView info = new TextView(this);
        info.setText("FootPredict utilise un serveur pour récupérer les matchs et calculer les prédictions.\n\nServeur FootPredict : https://josephatkazad2013.pythonanywhere.com");
        info.setPadding(0, 0, 0, 18);
        box.addView(info);
        box.addView(input);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Configuration du serveur")
                .setView(box)
                .setCancelable(!firstRun)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = input.getText().toString().trim();
            if (!value.startsWith("http://") && !value.startsWith("https://")) {
                input.setError("URL invalide"); return;
            }
            prefs.edit().putString(KEY_SERVER, value).apply();
            dialog.dismiss();
            loadServer();
        }));
        dialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        menu.add("Configuration").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
        menu.add("Actualiser").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if ("Configuration".contentEquals(item.getTitle())) { showServerDialog(false); return true; }
        if ("Actualiser".contentEquals(item.getTitle())) { loadServer(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
