# FootPredict — Projet Android Studio complet

Application Android WebView pour l'interface FootPredict V6.

## Architecture

- `app/src/main/java/.../MainActivity.java` : activité Android et WebView.
- `app/src/main/assets/web/index.html` : copie de l'interface Web FootPredict V6.
- L'application demande au premier lancement l'URL du serveur FootPredict.
- Le token Sportmonks doit rester sur le serveur et ne doit pas être placé dans l'APK.

## 1. Préparer le serveur

Décompresser `FootPredict_V6_Prediction_Advanced.zip` sur un serveur Node.js.
Créer `.env` à partir de `.env.example` et renseigner :

`SPORTMONKS_TOKEN=TON_TOKEN`

Puis lancer :

`npm install`

`npm start`

Le serveur doit être accessible depuis le téléphone, par exemple :

`https://footpredict.example.com`

Pour un serveur local sur le même Wi-Fi, utiliser l'adresse IP du PC, par exemple :

`http://192.168.1.20:3000`

## 2. Ouvrir dans Android Studio

Ouvrir le dossier `FootPredict_AndroidStudio` comme projet.
Android Studio téléchargera automatiquement Gradle 8.7 et les dépendances nécessaires.

SDK recommandé : Android API 35.
JDK recommandé : 17.

## 3. Générer un APK debug

Dans Android Studio :
`Build > Build Bundle(s) / APK(s) > Build APK(s)`

ou en terminal après installation de Gradle :

`./gradlew assembleDebug`

APK : `app/build/outputs/apk/debug/app-debug.apk`

## 4. Générer le release APK

Dans Android Studio :
`Build > Generate Signed App Bundle / APK > APK`

Créer ou sélectionner un keystore, choisir `release`, puis générer.

APK : `app/build/outputs/apk/release/app-release.apk`

## Important

Cette version est conçue pour garder le token Sportmonks hors de l'APK. L'APK est le client Android ; les données et les calculs restent côté serveur.

Pour une publication Play Store, remplacer HTTP local par HTTPS, définir une vraie signature release et utiliser une URL serveur stable.
