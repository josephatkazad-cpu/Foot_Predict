# FootPredict currently uses WebView only; keep default Android rules.
