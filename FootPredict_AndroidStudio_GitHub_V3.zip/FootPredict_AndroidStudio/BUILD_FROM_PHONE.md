# Construire FootPredict depuis un téléphone Android

1. Créer un dépôt GitHub.
2. Décompresser ce projet puis envoyer **le contenu du dossier FootPredict_AndroidStudio** dans le dépôt (pas le ZIP lui-même).
3. Ouvrir l'onglet Actions.
4. Sélectionner « Build FootPredict APK ».
5. Appuyer sur « Run workflow ».
6. Quand le workflow est vert, ouvrir l'exécution puis télécharger l'artifact « FootPredict-release ».
7. Décompresser l'artifact et installer `app-release-unsigned.apk`.

Pour une version Play Store, il faut ensuite signer l'APK avec une clé de production.
